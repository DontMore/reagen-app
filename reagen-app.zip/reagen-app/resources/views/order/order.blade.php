@extends('layout.main')

@section('container')

          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2">Order</h1>

            <a href="/new-order-form"><button>Order</button></a>
          </div>

          <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>No Catalog</th>
                    <th>Name Reagen</th>
                    <th>Merk</th>
                    <th>Pack Size</th>
                    <th>Quantity</th>
                    <th>User ID</th>
                    <th>Status</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($orders as $order)
                    <tr>
                        <td>{{ $order->id }}</td>
                        <td>{{ $order->noCatalog }}</td>
                        <td>{{ $order->nameReagen }}</td>
                        <td>{{ $order->merk }}</td>
                        <td>{{ $order->packSize }}</td>
                        <td>{{ $order->quantity }}</td>
                        <td>{{ $order->user->name }}</td>
                        <td>
                            <?php
                              if( $order->status == 0){
                                echo '<span class="badge text-bg-warning">Not Complate</span>';
                              }else{
                                echo '<span class="badge text-bg-success">Complate</span>';
                              }
                            ?>
                        </td>
                        <td>{{ $order->created_at }}</td>
                        <td>
                          <a href="{{ route('order.view', ['id' => $order->id]) }}"><button>View</button></a>
                          <button>Delete</button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

@endsection
