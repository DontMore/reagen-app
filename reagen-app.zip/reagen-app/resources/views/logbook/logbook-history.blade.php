<!-- logbook-take.blade.php -->

@extends('layout.main')

@section('container')
        <h1>Logbook History</h1>
            <p>Nomor Katalog : {{ $reagen->noCatalog }}</p>
            <p>Nama Reagen : {{ $reagen->namaReagen }}</p><br>
            <p>Merk : {{ $reagen->merk }}</p><br>
            <p>
            @foreach ($reagen->reagenIn as $stock)
                Batch : {{ $stock->batch }}
                Expired Date : {{ $stock->expiredDate }}<br>
            @endforeach
            </p>
            <p>Jumlah : {{ $reagen->reagenIn->sum('totalStock') }}</p>

        <h2>Logbook Information</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Quantity Taken</th>
                    <th>User</th>
                    <th>Note</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($reagen->logbookReagens as $logbook)
                    <tr>
                        <td>{{ $logbook->created_at }}</td>
                        <td>{{ $logbook->quantity_taken }}</td>
                        <td>{{ $logbook->user->name }}</td>
                        <td>{{ $logbook->note }}</td> <!-- Adjust the relationship and attribute based on your actual structure -->
                    </tr>
                @endforeach
            </tbody>
        </table>

@endsection
