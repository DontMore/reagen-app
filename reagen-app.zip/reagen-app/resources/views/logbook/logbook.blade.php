@extends('layout.main')

@section('container')

          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2">Logbook</h1>

            <!-- Tambahkan di dalam body halaman logbook Anda -->
            @if(session('alert'))
                <!-- Modal -->
                <div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="successModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="successModalLabel">Success</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                {{ session('alert.message') }}
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Script untuk menampilkan modal otomatis saat halaman dimuat -->
                <script>
                    $(document).ready(function(){
                        $('#successModal').modal('show');
                    });
                </script>
            @endif



            <!-- Form input Search -->
            <form action="{{ route('logbook.index') }}" method="GET">
                <input type="text" name="keyword" placeholder="Cari...">
                <button type="submit">Cari</button>
            </form>

          </div>

          <table class="table">
              <thead>
                  <tr>
                      <th scope="col">No</th>
                      <th scope="col">Nomor Katalog</th>
                      <th scope="col">Nama Reagen</th>
                      <th scope="col">Merk</th>
                      <th scope="col">Jumlah</th>
                      <th scope="col">Aksi</th>
                  </tr>
              </thead>
              <tbody>
                @foreach($reagens as $index => $reagen)
                  <tr>
                      <th scope="row">{{ $index + 1 }}</th>
                      <td>{{ $reagen->noCatalog }}</td>
                      <td>{{ $reagen->nameReagen }}</td>
                      <td>{{ $reagen->merk }}</td>
                      <td>{{ $reagen->totalStock }}</td>
                      <td>
                          <a href="{{ route('data.history', ['noCatalog' => $reagen->noCatalog]) }}" class="btn btn-primary btn-sm">View</a>
                          <a href="{{ route('data.take', ['noCatalog' => $reagen->noCatalog]) }}" class="btn btn-primary btn-sm">Take</a>
                      </td>
                  </tr>
                @endforeach
              </tbody>
          </table>

@endsection
