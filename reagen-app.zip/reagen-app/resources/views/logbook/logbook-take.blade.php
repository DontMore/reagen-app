<!-- logbook-take.blade.php -->

@extends('layout.main')

@section('container')
    <div class="container">

        <h1>Reagen Information</h1>
            {{ $reagen->noCatalog }}<br>
            {{ $reagen->namaReagen }}<br>
            {{ $reagen->merk }}<br>
            @foreach ($reagen->reagenIn as $stock)
                {{ $stock->batch }}
                {{ $stock->expiredDate }}<br>
            @endforeach
            {{ $reagen->reagenIn->sum('totalStock') }}

            <form action="/take-process" method="post">
            @csrf
                <div>
                    <input type="hidden" value="{{ $reagen->noCatalog }}" name="noCatalog">
                </div>

                <div>
                    <input type="hidden" value="{{ auth()->user()->id }}" name="user_id" readonly>
                </div>

                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Jumlah yang diambil</label>
                    <input type="number" class="form-control" name="quantity_taken" id="exampleFormControlInput1">
                </div>

                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Catatan</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" name="note" rows="3"></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
    </div>
@endsection
