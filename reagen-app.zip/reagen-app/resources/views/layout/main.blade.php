@include('partials.header')

@include('sweetalert::alert')

@include('partials.sidebar')

    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">      
        @yield('container')
    </main>

@include('partials.footer')
