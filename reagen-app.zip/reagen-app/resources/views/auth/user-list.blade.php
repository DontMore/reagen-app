<!-- logbook-take.blade.php -->
@extends('layout.main')

@section('container')
        
        <div>
            <h1>User List</h1>
            <a href="/register"><button>Create</button></a>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Aksi</th>
                    <!-- Tambahkan kolom-kolom lain sesuai kebutuhan -->
                </tr>
            </thead>
            <tbody>
                @foreach ($users as $user)
                    <tr>
                        <td>{{ $user->id }}</td>
                        <td>{{ $user->username }}</td>
                        <td>{{ $user->name }}</td>
                        <td>{{ $user->role }}</td>
                        <td>
                            <a href="">
                                <button>Edit</button>
                            </a>
                            <a href="">
                                <button>Delete </button>
                            </a>
                        </td>
                        <!-- Tambahkan kolom-kolom lain sesuai kebutuhan -->
                    </tr>
                @endforeach
            </tbody>
        </table>
@endsection
