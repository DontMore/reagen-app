@extends('layout.main')

@section('container')

      <!-- Judul halaman  -->
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h1 class="h2">Management Stock</h1>
      </div>

      <!-- Tombol add reagen dan search -->
      <div class="row">
        <!-- tombol add reagan -->
        <div class="col-md-2">
          <a href="/add-reagen"><button type="button" class="btn btn-success">Tambahkan</button></a>
        </div>

        <!-- search -->
        <div class="mb-3 col-md-10">
          <!-- Form input Search -->
          <form action="{{ route('management-stock') }}" method="GET">
                <input type="text" name="keyword" class="form-control" placeholder="Cari...">
                <button type="submit">Cari</button>
            </form>
        </div>
      </div>
          
      <div class="row mb-3">
        <div class="col">
          Catalog Number
        </div>

        <div class="col">
          Reagen Name
        </div>

        <div class="col">
          Merk
        </div>

        <div class="col">
          Amount
        </div>

        <div class="col">
        </div>
      </div>
      <!-- perulangan -->
          @foreach($reagens as $item)
      <div class="row mb-3">
            <div class="col">
              {{ $item->noCatalog }}
            </div>

            <div class="col">
            {{ $item->nameReagen }}
            </div>

            <div class="col">
            {{ $item->merk }}
            </div>

            <div class="col">
            {{ $item->totalStock }}
            </div>

            <div class="col">
              <div class="row">
                  <a href="{{ route('data.view', ['noCatalog' => $item->noCatalog]) }}">view</a> |
                  <a href="/add-stock-reagen">add</a> |
                  <a href="{{ route('data.edit', ['noCatalog' => $item->noCatalog]) }}">edit</a>
                  <form action="{{ route('data.delete', ['noCatalog' => $item->noCatalog]) }}" method="POST">
                        @csrf
                        <button class="btn btn-danger confirm-button" data-toggle="tooltip" title='Delete'>Delete</button>
                  </form>
              </div>
            </div>
      </div>
          @endforeach

      <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
      <script type="text/javascript">

          $('.confirm-button').click(function(event) {
              var form =  $(this).closest("form");
              event.preventDefault();
              swal({
                  title: `Are you sure you want to delete this row?`,
                  text: "It will gone forevert",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
              })
                  .then((willDelete) => {
                      if (willDelete) {
                          form.submit();
                      }
                  });
          });
      </script>

@endsection
