<?php

namespace App\Http\Controllers;
use App\Models\Reagen;
use App\Models\StockReagen;
use App\Models\LogbookReagen;
use RealRashid\SweetAlert\Facades\Alert;

use Illuminate\Http\Request;

class LogbookController extends Controller
{
    public function index(Request $request){
        $keyword = $request->input('keyword');
    
        // Query data Reagen dengan menggunakan Eloquent
        $query = Reagen::withCount(['reagenIn as totalStock' => function ($query) {
            $query->select(\DB::raw("SUM(quantity)"));
        }])
        ->with(['reagenIn' => function ($query) {
            $query->select('noCatalog', 'batch', 'expiredDate'); // Pilih kolom yang diinginkan
        }]);
    
        // Jika ada kata kunci pencarian, tambahkan kondisi pencarian
        if ($keyword) {
            $query->where(function ($q) use ($keyword) {
                $q->where('noCatalog', 'LIKE', '%' . $keyword . '%')
                  ->orWhere('nameReagen', 'LIKE', '%' . $keyword . '%')
                  ->orWhere('merk', 'LIKE', '%' . $keyword . '%');
            });
        }
    
        // Ambil data sesuai dengan hasil query
        $reagens = $query->get();
    
        return view('logbook.logbook', compact('reagens'));
    }

    // Fungsi takeReagen
    public function takeReagen($noCatalog){   
        $reagen = Reagen::with(['reagenIn' => function ($query) {
                $query->select('noCatalog', 'batch', 'expiredDate', \DB::raw("SUM(quantity) as totalStock"))
                    ->groupBy('noCatalog', 'batch', 'expiredDate');
            }])
            ->where('noCatalog', $noCatalog)
            ->first();
    
        return view('logbook.logbook-take', compact('reagen'));
    }    

    public function store(Request $request)
    {

    // Validasi form
    $validatedData = $request->validate([
        'noCatalog' => 'required', // Sesuaikan dengan aturan validasi yang diperlukan
        'user_id' => 'required',
        'quantity_taken' => 'required|numeric|min:1', // Contoh aturan validasi jumlah yang diambil harus numerik dan minimal 1
        'note' => 'nullable|string', // Catatan bersifat opsional dan harus string jika diisi
    ]);

    // Cetak data menggunakan dd atau var_dump atau print_r
    LogbookReagen::create($validatedData);

    // Tambahkan session flash untuk menampilkan pesan sukses
    session()->flash('alert', [
        'type' => 'success',
        'message' => 'Data has been saved successfully!',
    ]);

    // Redirect dengan pesan sukses atau tampilkan pesan sesuai kebutuhan
    return redirect()->route('logbook.index');
    }

    public function logbookHistory($noCatalog)
    {   
        $reagen = Reagen::with([
                'reagenIn' => function ($query) {
                    $query->select('noCatalog', 'batch', 'expiredDate', \DB::raw("SUM(quantity) as totalStock"))
                        ->groupBy('noCatalog', 'batch', 'expiredDate');
                },
                'logbookReagens' // This assumes the relationship is correctly defined in Reagen model
            ])
            ->where('noCatalog', $noCatalog)
            ->first();
        
        return view('logbook.logbook-history', compact('reagen'));
    }
     

}
