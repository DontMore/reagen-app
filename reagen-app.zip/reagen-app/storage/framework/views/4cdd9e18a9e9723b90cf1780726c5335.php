<?php $__env->startSection('container'); ?>

          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2">Add Reagen</h1>
          </div>

        <form action="/add-reagen" method="POST">
            <?php echo csrf_field(); ?>
            <!-- nomor katalog -->
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Catalog Number</label>
                <input type="text" class="form-control" name="noCatalog" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <!-- nama reagen -->
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Reagen Name</label>
                <input type="text" class="form-control" name="nameReagen" id="exampleInputPassword1">
            </div>
            <!-- merk -->
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Merk</label>
                <input type="text" class="form-control" name="merk" id="exampleInputPassword1">
            </div>
            <!-- Pack Size -->
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Pack Size</label>
                <input type="text" class="form-control" name="packSize" id="exampleInputPassword1">
            </div>

            <!-- Hazard Symbol -->
            <div class="custom-control custom-checkbox mb-3 row" id="checkboxContainer">
                <label for="exampleInputPassword1" class="form-label">Hazard Symbol</label><br>

                <!-- Toxic Symbol -->
                <div class="form-check form-check-inline">
                    <input type="checkbox" class="custom-control-input custom-checkbox-input" id="customCheck1" name="hazardOptions[]" value="Toxic">
                    <label class="custom-control-label" for="customCheck1">
                        <img src="<?php echo e(asset('images/toxic.png')); ?>" alt="Gambar" width="100" height="100" class="customCheck1Image custom-control-image">
                    </label>
                </div>

                <!-- Corrosive Symbol -->
                <div class="form-check form-check-inline">
                    <input type="checkbox" class="custom-control-input custom-checkbox-input" id="customCheck2" name="hazardOptions[]" value="Corrosive">
                    <label class="custom-control-label" for="customCheck2">
                        <img src="<?php echo e(asset('images/corrosive.png')); ?>" alt="Gambar" width="100" height="100" class="customCheck2Image custom-control-image">
                    </label>
                </div>

                <!-- Explosive Symbol -->
                <div class="form-check form-check-inline">
                    <input type="checkbox" class="custom-control-input custom-checkbox-input" id="customCheck3" name="hazardOptions[]" value="Explosive">
                    <label class="custom-control-label" for="customCheck3">
                        <img src="<?php echo e(asset('images/explosive.png')); ?>" alt="Gambar" width="100" height="100" class="customCheck3Image custom-control-image">
                    </label>
                </div>
            </div>

            <!-- MSDS -->
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">MSDS</label>
                <input type="text" class="form-control" name="msds" id="exampleInputPassword1">
            </div>
            <!-- Price -->
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Price</label>
                <input type="text" class="form-control" name="price" id="exampleInputPassword1">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\reagen-app\resources\views/management-stock/add-reagen.blade.php ENDPATH**/ ?>