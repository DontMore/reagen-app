<?php $__env->startSection('container'); ?>

          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2">Add Reagen</h1>
          </div>

          <form method="POST" action="<?php echo e(route('data.update', $data->noCatalog)); ?>">
            <?php echo csrf_field(); ?>
            
            <!-- nomor katalog -->
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Catalog Number</label>
                <input type="text" class="form-control" name="noCatalog" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($data->noCatalog); ?>" readonly>
            </div>
            <!-- nama reagen -->
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Reagen Name</label>
                <input type="text" class="form-control" name="nameReagen" id="exampleInputPassword1" value="<?php echo e($data->nameReagen); ?>">
            </div>
            <!-- merk -->
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Merk</label>
                <input type="text" class="form-control" name="merk" id="exampleInputPassword1" value="<?php echo e($data->merk); ?>">
            </div>
            <!-- Pack Size -->
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Pack Size</label>
                <input type="text" class="form-control" name="packSize" id="exampleInputPassword1" value="<?php echo e($data->packSize); ?>">
            </div>

             <!-- Hazard Symbol -->
             <div class="custom-control custom-checkbox mb-3 row" id="checkboxContainer">
                <label for="exampleInputPassword1" class="form-label">Hazard Symbol</label><br>

                <!-- Toxic Symbol -->
                <div class="form-check form-check-inline">
                    <input type="checkbox" class="custom-control-input custom-checkbox-input" id="customCheck1" name="hazardOptions[]" value="Toxic" <?php echo e(in_array('Toxic', $hazardOptions) ? 'checked' : ''); ?>>
                    <label class="custom-control-label" for="customCheck1">
                        <img src="<?php echo e(asset('images/toxic.png')); ?>" alt="Gambar" width="100" height="100" class="customCheck1Image custom-control-image">
                    </label>
                </div>

                <!-- Corrosive Symbol -->
                <div class="form-check form-check-inline">
                    <input type="checkbox" class="custom-control-input custom-checkbox-input" id="customCheck2" name="hazardOptions[]" value="Corrosive" <?php echo e(in_array('Corrosive', $hazardOptions) ? 'checked' : ''); ?>>
                    <label class="custom-control-label" for="customCheck2">
                        <img src="<?php echo e(asset('images/corrosive.png')); ?>" alt="Gambar" width="100" height="100" class="customCheck2Image custom-control-image">
                    </label>
                </div>

                <!-- Explosive Symbol -->
                <div class="form-check form-check-inline">
                    <input type="checkbox" class="custom-control-input custom-checkbox-input" id="customCheck3" name="hazardOptions[]" value="Explosive" <?php echo e(in_array('Explosive', $hazardOptions) ? 'checked' : ''); ?>>
                    <label class="custom-control-label" for="customCheck3">
                        <img src="<?php echo e(asset('images/explosive.png')); ?>" alt="Gambar" width="100" height="100" class="customCheck3Image custom-control-image">
                    </label>
                </div>
            </div>

            <!-- MSDS -->
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">MSDS</label>
                <input type="text" class="form-control" name="msds" id="exampleInputPassword1" value="<?php echo e($data->msds); ?>">
            </div>
            <!-- Price -->
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Price</label>
                <input type="text" class="form-control" name="price" id="exampleInputPassword1" value="<?php echo e($data->price); ?>">
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\reagen-app\resources\views/management-stock/edit-reagen.blade.php ENDPATH**/ ?>