

<?php $__env->startSection('container'); ?>

          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2">Eksisting Order Form</h1>
          </div>

          <div>
            <a href="/new-order-form"><button>New Order</button></a>
            <a href="/eksisting-order-form"><button>Eksisting Order</button></a>
          </div>

          <form action="<?php echo e(route('orders.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <!-- Nomor Katalog -->
            <div class="form-group">
                <label for="nomorKatalog">Nomor Katalog</label>
                <select class="form-control" id="nomorKatalog" name="noCatalog">
                    <option value="" selected>Pilih Reagen</option>
                    <?php $__currentLoopData = $reagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($reagen->noCatalog); ?>"><?php echo e($reagen->noCatalog); ?> - <?php echo e($reagen->nameReagen); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

             <!-- Nama Reagen -->
             <div class="form-group">
                <label for="namaReagen">Nama Reagen</label>
                <input type="text" class="form-control" id="namaReagen" name="nameReagen" readonly>
            </div>

            <!-- Merk -->
            <div class="form-group">
                <label for="merk">Merk</label>
                <input type="text" class="form-control" id="merk" name="merk" readonly>
            </div>

            <div class="form-group">
                <label for="packSize">Pack Size:</label>
                <input type="text" class="form-control" id="packSize" name="packSize" readonly>
            </div>

            <div class="form-group">
                <label for="quantity">Quantity:</label>
                <input type="number" class="form-control" id="quantity" name="quantity" required>
            </div>

            <div class="form-group">
                <input type="hidden" class="form-control" id="status" name="status" value="0" readonly>
                <input type="hidden" class="form-control" id="userId" name="userId" value="<?php echo e(auth()->user()->id); ?>" readonly>
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>

        <!-- AJAX Script -->
        <script>
            $(document).ready(function(){
                $('#nomorKatalog').on('change', function(){
                    var noCatalogUtama = $(this).val();
                    if(noCatalogUtama) {
                        $.ajax({
                            url: '/reagen/'+noCatalogUtama,
                            type: "GET",
                            dataType: "json",
                            success:function(data) {
                                $('#namaReagen').val(data.nameReagen);
                                $('#merk').val(data.merk);
                                $('#packSize').val(data.packSize);
                            }
                        });
                    } else {
                        $('#namaReagen').val('');
                        $('#merk').val('');
                        $('#packSize').val('');
                    }
                });
            });
        </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\reagen-app\resources\views/order/eksisting-order-form.blade.php ENDPATH**/ ?>