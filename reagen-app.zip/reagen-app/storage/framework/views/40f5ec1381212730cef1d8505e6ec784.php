<?php $__env->startSection('container'); ?>

          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2">Logbook</h1>

            <!-- Form input Search -->
            <form action="<?php echo e(route('logbook.index')); ?>" method="GET">
                <input type="text" name="keyword" placeholder="Cari...">
                <button type="submit">Cari</button>
            </form>

          </div>

          <table class="table">
              <thead>
                  <tr>
                      <th scope="col">No</th>
                      <th scope="col">Nomor Katalog</th>
                      <th scope="col">Nama Reagen</th>
                      <th scope="col">Merk</th>
                      <th scope="col">Jumlah</th>
                      <th scope="col">Aksi</th>
                  </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $reagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $reagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <th scope="row"><?php echo e($index + 1); ?></th>
                      <td><?php echo e($reagen->noCatalog); ?></td>
                      <td><?php echo e($reagen->nameReagen); ?></td>
                      <td><?php echo e($reagen->merk); ?></td>
                      <td><?php echo e($reagen->totalStock); ?></td>
                      <td>
                          <a href="<?php echo e(route('data.history', ['noCatalog' => $reagen->noCatalog])); ?>" class="btn btn-primary btn-sm">View</a>
                          <a href="<?php echo e(route('data.take', ['noCatalog' => $reagen->noCatalog])); ?>" class="btn btn-primary btn-sm">Take</a>
                      </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhardi\reagen-app\resources\views/logbook/logbook.blade.php ENDPATH**/ ?>