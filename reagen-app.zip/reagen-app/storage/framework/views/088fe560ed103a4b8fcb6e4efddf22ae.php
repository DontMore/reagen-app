<?php $__env->startSection('container'); ?>

      <!-- Judul halaman  -->
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h1 class="h2">Management Stock</h1>
      </div>

      <!-- Tombol add reagen dan search -->
      <div class="row">
        <!-- tombol add reagan -->
        <div class="col-md-2">
          <a href="/add-reagen"><button type="button" class="btn btn-success">Tambahkan</button></a>
        </div>

        <!-- search -->
        <div class="mb-3 col-md-10">
          <!-- Form input Search -->
          <form action="<?php echo e(route('management-stock')); ?>" method="GET">
                <input type="text" name="keyword" class="form-control" placeholder="Cari...">
                <button type="submit">Cari</button>
            </form>
        </div>
      </div>
          
      <div class="row mb-3">
        <div class="col">
          Catalog Number
        </div>

        <div class="col">
          Reagen Name
        </div>

        <div class="col">
          Merk
        </div>

        <div class="col">
          Amount
        </div>

        <div class="col">
        </div>
      </div>
      <!-- perulangan -->
          <?php $__currentLoopData = $reagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row mb-3">
            <div class="col">
              <?php echo e($item->noCatalog); ?>

            </div>

            <div class="col">
            <?php echo e($item->nameReagen); ?>

            </div>

            <div class="col">
            <?php echo e($item->merk); ?>

            </div>

            <div class="col">
            <?php echo e($item->totalStock); ?>

            </div>

            <div class="col">
              <div class="row">
                  <a href="<?php echo e(route('data.view', ['noCatalog' => $item->noCatalog])); ?>">view</a> |
                  <a href="/add-stock-reagen">add</a> |
                  <a href="<?php echo e(route('data.edit', ['noCatalog' => $item->noCatalog])); ?>">edit</a>
                  <form action="<?php echo e(route('data.delete', ['noCatalog' => $item->noCatalog])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit">Delete</button>
                  </form>
              </div>
            </div>
      </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhardi\reagen-app\resources\views/management-stock/management-stock.blade.php ENDPATH**/ ?>