<!-- logbook-take.blade.php -->



<?php $__env->startSection('container'); ?>
        <h1>Logbook History</h1>
            <p>Nomor Katalog : <?php echo e($reagen->noCatalog); ?></p>
            <p>Nama Reagen : <?php echo e($reagen->namaReagen); ?></p><br>
            <p>Merk : <?php echo e($reagen->merk); ?></p><br>
            <p>
            <?php $__currentLoopData = $reagen->stockReagen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                Batch : <?php echo e($stock->batch); ?>

                Expired Date : <?php echo e($stock->expiredDate); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
            <p>Jumlah : <?php echo e($reagen->stockReagen->sum('totalStock')); ?></p>

        <h2>Logbook Information</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Quantity Taken</th>
                    <th>User</th>
                    <th>Note</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reagen->logbookReagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logbook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($logbook->created_at); ?></td>
                        <td><?php echo e($logbook->quantity_taken); ?></td>
                        <td><?php echo e($logbook->user->name); ?></td>
                        <td><?php echo e($logbook->note); ?></td> <!-- Adjust the relationship and attribute based on your actual structure -->
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhardi\reagen-app\resources\views/logbook/logbook-history.blade.php ENDPATH**/ ?>