<!-- logbook-take.blade.php -->


<?php $__env->startSection('container'); ?>
        
        <div>
            <h1>User List</h1>
            <a href="/register"><button>Create</button></a>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Aksi</th>
                    <!-- Tambahkan kolom-kolom lain sesuai kebutuhan -->
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->username); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->role); ?></td>
                        <td>
                            <a href="">
                                <button>Edit</button>
                            </a>
                            <a href="">
                                <button>Delete </button>
                            </a>
                        </td>
                        <!-- Tambahkan kolom-kolom lain sesuai kebutuhan -->
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhardi\reagen-app\resources\views/auth/user-list.blade.php ENDPATH**/ ?>