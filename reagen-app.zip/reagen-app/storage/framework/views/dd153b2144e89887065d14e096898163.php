<?php $__env->startSection('container'); ?>
<div class="container">
        <h2>Add Stock Reagen</h2>
        <form action="/add-stock-reagen" method="POST">
            <?php echo csrf_field(); ?>
            <!-- Nomor Katalog -->
            <div class="form-group">
                <label for="nomorKatalog">Nomor Katalog</label>
                <select class="form-control" id="nomorKatalog" name="noCatalog">
                    <option value="" selected>Pilih Reagen</option>
                    <?php $__currentLoopData = $reagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($reagen->noCatalog); ?>"><?php echo e($reagen->noCatalog); ?> - <?php echo e($reagen->nameReagen); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Nama Reagen -->
            <div class="form-group">
                <label for="namaReagen">Nama Reagen</label>
                <input type="text" class="form-control" id="namaReagen" readonly>
            </div>

            <!-- Merk -->
            <div class="form-group">
                <label for="merk">Merk</label>
                <input type="text" class="form-control" id="merk" readonly>
            </div>

             <!-- Nomor Batch -->
             <div class="form-group">
                <label for="merk">Nomor Batch</label>
                <input type="text" class="form-control" id="batch" name="batch">
            </div>

            <!-- Jumlah -->
            <div class="form-group">
                <label for="jumlah">Jumlah</label>
                <input type="number" name="quantity" class="form-control" id="jumlah">
            </div>

            <!-- Tanggal Kadaluarsa -->
            <div class="form-group">
                <label for="tanggalKadaluarsa">Tanggal Kadaluarsa</label>
                <input type="date" name="expiredDate" class="form-control" id="tanggalKadaluarsa">
            </div>

            <!-- Catatan -->
            <div class="form-group">
                <label for="catatan">Catatan</label>
                <textarea class="form-control" name="note" id="catatan" rows="3"></textarea>
            </div>

            <!-- Tombol Submit -->
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
    </div>

    <!-- AJAX Script -->
    <script>
        $(document).ready(function(){
            $('#nomorKatalog').on('change', function(){
                var noCatalogUtama = $(this).val();
                if(noCatalogUtama) {
                    $.ajax({
                        url: '/reagen/'+noCatalogUtama,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            $('#namaReagen').val(data.nameReagen);
                            $('#merk').val(data.merk);
                        }
                    });
                } else {
                    $('#namaReagen').val('');
                    $('#merk').val('');
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\reagen-app\resources\views/management-stock/add-stock-reagen.blade.php ENDPATH**/ ?>