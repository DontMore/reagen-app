<?php $__env->startSection('container'); ?>

          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2">Order</h1>

            <a href="/order-form"><button>Order</button></a>
          </div>

          <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>No Catalog</th>
                    <th>Name Reagen</th>
                    <th>Merk</th>
                    <th>Pack Size</th>
                    <th>Quantity</th>
                    <th>User ID</th>
                    <th>Status</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->noCatalog); ?></td>
                        <td><?php echo e($order->nameReagen); ?></td>
                        <td><?php echo e($order->merk); ?></td>
                        <td><?php echo e($order->packSize); ?></td>
                        <td><?php echo e($order->quantity); ?></td>
                        <td><?php echo e($order->userId); ?></td>
                        <td><?php echo e($order->status); ?></td>
                        <td><?php echo e($order->created_at); ?></td>
                        <td>
                          <button>View</button>
                          <button>Delete</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhardi\reagen-app\resources\views/order/order.blade.php ENDPATH**/ ?>