<?php $__env->startSection('container'); ?>
                <h2 class="mb-4">Register</h2>
                <form method="POST" action="/register">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter your full name" required>
                    </div>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Choose a username" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter a password" required>
                    </div>
                    <div class="form-group">
                        <label for="repassword">Re-enter Password</label>
                        <input type="password" class="form-control" id="repassword" name="repassword" placeholder="Re-enter your password" required>
                    </div>
                    <div class="form-group">
                        <label for="role">Role</label>
                        <select class="form-control" id="role" name="role" required>
                            <option value="">Select a role</option>
                            <option value="Admin">Admin</option>
                            <option value="analis">Analis</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Submit</button>
                </form>

<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhardi\reagen-app\resources\views/auth/register.blade.php ENDPATH**/ ?>