

<?php $__env->startSection('container'); ?>

          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2">New Order Form</h1>
          </div>

          <div>
            <a href="/new-order-form"><button>New Order</button></a>
            <a href="/eksisting-order-form"><button>Eksisting Order</button></a>
          </div>

          <form action="<?php echo e(route('orders.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="noCatalog">No Catalog:</label>
                <input type="text" class="form-control" id="noCatalog" name="noCatalog" required>
            </div>

            <div class="form-group">
                <label for="nameReagen">Name Reagen:</label>
                <input type="text" class="form-control" id="nameReagen" name="nameReagen" required>
            </div>

            <div class="form-group">
                <label for="merk">Merk:</label>
                <input type="text" class="form-control" id="merk" name="merk" required>
            </div>

            <div class="form-group">
                <label for="packSize">Pack Size:</label>
                <input type="text" class="form-control" id="packSize" name="packSize" required>
            </div>

            <div class="form-group">
                <label for="quantity">Quantity:</label>
                <input type="number" class="form-control" id="quantity" name="quantity" required>
            </div>

            <div class="form-group">
                <input type="hidden" class="form-control" id="status" name="status" value="0" readonly>
                <input type="hidden" class="form-control" id="userId" name="userId" value="<?php echo e(auth()->user()->id); ?>" readonly>
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\reagen-app\resources\views/order/new-order-form.blade.php ENDPATH**/ ?>