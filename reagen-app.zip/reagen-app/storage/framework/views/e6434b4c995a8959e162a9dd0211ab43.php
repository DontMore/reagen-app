<!-- logbook-take.blade.php -->



<?php $__env->startSection('container'); ?>
    <div class="container">
        <h1>Reagen Information</h1>
            <?php echo e($reagen->noCatalog); ?><br>
            <?php echo e($reagen->namaReagen); ?><br>
            <?php echo e($reagen->merk); ?><br>
            <?php $__currentLoopData = $reagen->stockReagen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($stock->batch); ?>

                <?php echo e($stock->expiredDate); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($reagen->stockReagen->sum('totalStock')); ?>


            <form action="/take-process" method="post">
            <?php echo csrf_field(); ?>
                <div>
                    <input type="hidden" value="<?php echo e($reagen->noCatalog); ?>" name="noCatalog">
                </div>

                <div>
                    <input type="hidden" value="<?php echo e(auth()->user()->id); ?>" name="user_id" readonly>
                </div>

                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Jumlah yang diambil</label>
                    <input type="number" class="form-control" name="quantity_taken" id="exampleFormControlInput1">
                </div>

                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Catatan</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" name="note" rows="3"></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Muhardi\reagen-app\resources\views/logbook/logbook-take.blade.php ENDPATH**/ ?>